# Lumos English - React Native Mobile App

A React Native WebView application that provides a mobile app experience for https://english.lumos.com.ge

## 📱 App Details

- **App Name:** Lumos English  
- **Package Name (Android):** com.lumos.english  
- **Bundle ID (iOS):** com.lumos.english  
- **Website URL:** https://english.lumos.com.ge
- **React Native Version:** 0.82.0

## ✨ Features

✅ Full WebView implementation of your Django website  
✅ Android hardware back button support for navigation  
✅ Loading indicator while pages load  
✅ Error handling with offline message  
✅ JavaScript and DOM storage enabled  
✅ Proper status bar configuration  
✅ Safe area handling for notched devices

## 🚀 Quick Start

### Prerequisites

Before building, you need to install:

1. **Node.js** (v18 or higher) - https://nodejs.org
2. **Java Development Kit (JDK) 17** - https://adoptium.net/
3. **Android Studio** - https://developer.android.com/studio
   - Android SDK Platform 34
   - Android SDK Build-Tools 34.0.0
4. **For iOS (macOS only):**
   - Xcode 14+
   - CocoaPods

### Installation

```bash
# Navigate to project directory
cd LumosEnglish

# Install dependencies
npm install
```

### Building for Android

#### Option 1: Debug Build (Quick Testing)

```bash
# Method A: Using Gradle directly
cd android
./gradlew assembleDebug

# The APK will be at:
# android/app/build/outputs/apk/debug/app-debug.apk
```

```bash
# Method B: Using React Native CLI
npx react-native run-android
# (Requires connected device or running emulator)
```

#### Option 2: Release Build (Production)

See `BUILD_INSTRUCTIONS.md` for detailed steps on creating a signed release APK.

### Building for iOS

```bash
# Install iOS dependencies
cd ios
pod install
cd ..

# Run on simulator
npx react-native run-ios

# For physical device:
# 1. Open ios/LumosEnglish.xcworkspace in Xcode
# 2. Select your development team
# 3. Connect your device
# 4. Build and run
```

## 📦 Project Structure

```
LumosEnglish/
├── App.tsx                    # Main WebView component
├── android/                   # Android native code
│   ├── app/
│   │   ├── build.gradle      # App configuration
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       └── java/com/lumos/english/  # Native code
│   └── build.gradle          # Project configuration
├── ios/                      # iOS native code
│   ├── LumosEnglish/
│   └── LumosEnglish.xcodeproj/
├── package.json              # Dependencies
├── BUILD_INSTRUCTIONS.md     # Detailed build guide
└── QUICK_START.md           # Quick reference guide
```

## 🔧 Customization

### Change Website URL

Edit `App.tsx`:
```typescript
const WEBSITE_URL = 'https://your-new-url.com';
```

### Change App Name

- **Android:** `android/app/src/main/res/values/strings.xml`
- **iOS:** In Xcode project settings

### Change Package/Bundle ID

- **Android:** `android/app/build.gradle` (namespace and applicationId)
- **iOS:** In Xcode project settings

## 🐛 Troubleshooting

### "SDK location not found"

Create `android/local.properties`:
```
sdk.dir=/path/to/your/Android/Sdk
```

On macOS: Usually `/Users/YOUR_USERNAME/Library/Android/sdk`  
On Windows: Usually `C:\Users\YOUR_USERNAME\AppData\Local\Android\Sdk`  
On Linux: Usually `/home/YOUR_USERNAME/Android/Sdk`

### Build fails with "Could not find or load main class"

Make sure JDK 17 is installed and JAVA_HOME is set:
```bash
export JAVA_HOME=/path/to/jdk-17
```

### "No bundle identifier found" (iOS)

Open the project in Xcode and set the bundle identifier in project settings.

## 📱 Installing on Device

### Android

1. Build the debug APK (see above)
2. Transfer `app-debug.apk` to your Android device
3. Enable "Install from Unknown Sources" in Settings
4. Open the APK file and install

Or use ADB:
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### iOS

You need to build through Xcode with a valid Apple Developer account and install via Xcode.

## 🚀 Publishing

### Google Play Store

1. Create a signed release APK (see BUILD_INSTRUCTIONS.md)
2. Create a Google Play Developer account ($25 one-time fee)
3. Create a new app in Google Play Console
4. Upload your APK
5. Fill in app details, screenshots, description
6. Submit for review

### Apple App Store

1. Create an Apple Developer account ($99/year)
2. Create App ID in Apple Developer Portal
3. Create app in App Store Connect
4. Archive in Xcode (Product > Archive)
5. Upload to App Store Connect
6. Fill in app details and submit for review

## 📖 Documentation

- **BUILD_INSTRUCTIONS.md** - Complete step-by-step build guide
- **QUICK_START.md** - Fast reference for getting started
- **React Native Docs** - https://reactnative.dev/docs/getting-started

## 💡 Tips

- For development, use `npx react-native start` to start Metro bundler
- Use `npx react-native log-android` to view Android logs
- Use `npx react-native log-ios` to view iOS logs
- Enable hot reload for faster development
- Test on real devices for accurate performance

## 🆘 Need Help?

If you encounter issues:

1. Check `BUILD_INSTRUCTIONS.md` for detailed troubleshooting
2. Ensure all prerequisites are properly installed
3. Check React Native documentation: https://reactnative.dev
4. For Android issues: https://developer.android.com
5. For iOS issues: https://developer.apple.com/xcode

## 📄 License

This project is configured for the Lumos English mobile application.

---

**Version:** 1.0.0  
**Created:** 2025  
**Target:** Android 6.0+ (API 24+), iOS 13.0+