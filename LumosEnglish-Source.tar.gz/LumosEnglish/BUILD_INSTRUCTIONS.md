# Lumos English - Mobile App Build Instructions

This is a React Native WebView application for https://english.lumos.com.ge

## App Configuration

- **App Name:** Lumos English
- **Package Name (Android):** com.lumos.english
- **Bundle ID (iOS):** com.lumos.english
- **Website URL:** https://english.lumos.com.ge

## Prerequisites

### For Android Build:

1. **Node.js** (v18 or higher)
2. **Java Development Kit (JDK)** 17 or higher
3. **Android Studio** with Android SDK
4. **React Native CLI**

### For iOS Build:

1. **macOS** (required for iOS builds)
2. **Xcode** 14 or higher
3. **CocoaPods**
4. **Node.js** (v18 or higher)

## Installation

```bash
# Install dependencies
cd LumosEnglish
npm install
```

## Building for Android

### Method 1: Debug APK (for testing)

```bash
# Navigate to android directory
cd android

# Build debug APK
./gradlew assembleDebug

# The APK will be located at:
# android/app/build/outputs/apk/debug/app-debug.apk
```

### Method 2: Release APK (for production)

First, you need to generate a signing key:

```bash
# Generate keystore (one-time setup)
keytool -genkeypair -v -storetype PKCS12 -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000

# Place the keystore in android/app/
mv my-release-key.keystore android/app/
```

Edit `android/gradle.properties` and add:

```properties
MYAPP_RELEASE_STORE_FILE=my-release-key.keystore
MYAPP_RELEASE_KEY_ALIAS=my-key-alias
MYAPP_RELEASE_STORE_PASSWORD=****
MYAPP_RELEASE_KEY_PASSWORD=****
```

Edit `android/app/build.gradle`, add release signing config:

```gradle
android {
    ...
    signingConfigs {
        release {
            if (project.hasProperty('MYAPP_RELEASE_STORE_FILE')) {
                storeFile file(MYAPP_RELEASE_STORE_FILE)
                storePassword MYAPP_RELEASE_STORE_PASSWORD
                keyAlias MYAPP_RELEASE_KEY_ALIAS
                keyPassword MYAPP_RELEASE_KEY_PASSWORD
            }
        }
    }
    buildTypes {
        release {
            ...
            signingConfig signingConfigs.release
        }
    }
}
```

Build the release APK:

```bash
cd android
./gradlew assembleRelease

# The APK will be at:
# android/app/build/outputs/apk/release/app-release.apk
```

### Method 3: Using React Native CLI

```bash
# Debug build
npx react-native run-android

# Release build
npx react-native run-android --variant=release
```

## Building for iOS

```bash
# Install iOS dependencies
cd ios
pod install
cd ..

# Run on iOS simulator
npx react-native run-ios

# For physical device, open in Xcode:
open ios/LumosEnglish.xcworkspace

# In Xcode:
# 1. Select your development team in Signing & Capabilities
# 2. Connect your iOS device
# 3. Select your device from the scheme dropdown
# 4. Click the Play button to build and run
```

## Running the App in Development

### Android:

```bash
# Start Metro bundler
npx react-native start

# In another terminal, run:
npx react-native run-android
```

### iOS:

```bash
# Start Metro bundler
npx react-native start

# In another terminal, run:
npx react-native run-ios
```

## Installing APK on Android Device

1. Transfer the APK file to your Android device
2. Enable "Install from Unknown Sources" in device settings
3. Open the APK file and install

Or use ADB:

```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

## Troubleshooting

### Android Build Issues:

**Issue:** Build fails with "SDK location not found"
**Solution:** Create `android/local.properties`:
```
sdk.dir=/path/to/your/Android/sdk
```

**Issue:** "Execution failed for task ':app:installDebug'"
**Solution:** Make sure an Android device is connected or emulator is running:
```bash
adb devices
```

### iOS Build Issues:

**Issue:** "No bundle identifier found"
**Solution:** Open the project in Xcode and set the bundle identifier in the project settings.

**Issue:** Pod install fails
**Solution:** 
```bash
cd ios
pod deintegrate
pod install
```

## Features

- Full WebView implementation of https://english.lumos.com.ge
- Android hardware back button support
- Loading indicator
- Error handling with offline message
- JavaScript enabled for full website functionality
- Proper navigation handling

## Customization

### Change Website URL:

Edit `App.tsx` and modify:
```typescript
const WEBSITE_URL = 'https://your-new-url.com';
```

### Change App Name:

- **Android:** Edit `android/app/src/main/res/values/strings.xml`
- **iOS:** Edit `ios/LumosEnglish/Info.plist` (CFBundleDisplayName)

### Change Package/Bundle ID:

- **Android:** Update in `android/app/build.gradle`
- **iOS:** Update in Xcode project settings

## Publishing

### Google Play Store:

1. Create a release APK (see above)
2. Create a Google Play Developer account
3. Create a new app in Google Play Console
4. Upload the APK
5. Fill in app details and submit for review

### Apple App Store:

1. Create an Apple Developer account
2. Create App ID in Apple Developer Portal
3. Create app in App Store Connect
4. Archive the app in Xcode (Product > Archive)
5. Upload to App Store Connect
6. Fill in app details and submit for review

## Support

For React Native issues: https://reactnative.dev/docs/getting-started
For Android Studio: https://developer.android.com/studio
For Xcode: https://developer.apple.com/xcode/

---

**Version:** 1.0.0  
**React Native Version:** 0.82.0  
**Last Updated:** 2025
